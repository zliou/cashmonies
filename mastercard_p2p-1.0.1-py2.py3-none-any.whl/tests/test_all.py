#
# Copyright (c) 2016 MasterCard International Incorporated
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are
# permitted provided that the following conditions are met:
#
# Redistributions of source code must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# Redistributions in binary form must reproduce the above copyright notice, this list of
# conditions and the following disclaimer in the documentation and/or other materials
# provided with the distribution.
# Neither the name of the MasterCard International Incorporated nor the names of its
# contributors may be used to endorse or promote products derived from this software
# without specific prior written permission.
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
#

import unittest
import time
from mastercardapicore import RequestMap
from base_test import BaseTest
from mastercardp2p import *


class SanctionScreeningTest(BaseTest):

    def setUp(self):
        Config.setDebug(True)
        self.resetAuthentication()

    
        
        
                
    def test_8001_RetrieveAccountInfoWithEligibleAccountInformation(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("fields", "metadata")
        map.set("account_info.account_uri", "pan:5102589999999905;exp=2017-08;cvc=123")
        map.set("account_info.amount", "1000")
        map.set("account_info.currency", "USD")
        map.set("account_info.payment_type", "BDB")
        
        
        response = AccountInfo(map).read()

        ignoreAsserts = []
        ignoreAsserts.append("account_info.funds_availability")
        ignoreAsserts.append("account_info.institution_name")
        
        self.customAssertEqual(ignoreAsserts, "account_info.sending_eligibility.eligible", response.get("account_info.sending_eligibility.eligible"),"true")
        self.customAssertEqual(ignoreAsserts, "account_info.receiving_eligibility.eligible", response.get("account_info.receiving_eligibility.eligible"),"true")
        self.customAssertEqual(ignoreAsserts, "account_info.type", response.get("account_info.type"),"DEBIT")
        self.customAssertEqual(ignoreAsserts, "account_info.brand", response.get("account_info.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account_info.funds_availability", response.get("account_info.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "account_info.product_type", response.get("account_info.product_type"),"Consumer")
        self.customAssertEqual(ignoreAsserts, "account_info.institution_name", response.get("account_info.institution_name"),"ABC Bank ")
        self.customAssertEqual(ignoreAsserts, "account_info.institution_country", response.get("account_info.institution_country"),"USA")
        self.customAssertEqual(ignoreAsserts, "account_info.account_statement_currency", response.get("account_info.account_statement_currency"),"USD")
        

        BaseTest.putResponse("RetrieveAccountInfoWithEligibleAccountInformation", response)
        

    
        
        
        
        
        
    
        
        
                
    def test_8002_RetrieveAccountInfoWithIneligibleAccountInformation(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("fields", "metadata")
        map.set("account_info.account_uri", "pan:5432123456789012;exp=2017-02;cvc=123")
        map.set("account_info.amount", "1000")
        map.set("account_info.currency", "USD")
        map.set("account_info.payment_type", "BDB")
        
        
        response = AccountInfo(map).read()

        ignoreAsserts = []
        ignoreAsserts.append("account_info.receiving_eligibility")
        ignoreAsserts.append("account_info.receiving_eligibility.eligible")
        
        self.customAssertEqual(ignoreAsserts, "account_info.sending_eligibility.eligible", response.get("account_info.sending_eligibility.eligible"),"false")
        self.customAssertEqual(ignoreAsserts, "account_info.sending_eligibility.reason_code", response.get("account_info.sending_eligibility.reason_code"),"ACCOUNT_NOT_ELIGIBLE")
        self.customAssertEqual(ignoreAsserts, "account_info.sending_eligibility.reason_description", response.get("account_info.sending_eligibility.reason_description"),"Account not eligible")
        self.customAssertEqual(ignoreAsserts, "account_info.receiving_eligibility.eligible", response.get("account_info.receiving_eligibility.eligible"),"false")
        self.customAssertEqual(ignoreAsserts, "account_info.receiving_eligibility.reason_code", response.get("account_info.receiving_eligibility.reason_code"),"ACCOUNT_NOT_ELIGIBLE")
        self.customAssertEqual(ignoreAsserts, "account_info.receiving_eligibility.reason_description", response.get("account_info.receiving_eligibility.reason_description"),"Account not eligible")
        self.customAssertEqual(ignoreAsserts, "account_info.brand", response.get("account_info.brand"),"MasterCard")
        

        BaseTest.putResponse("RetrieveAccountInfoWithIneligibleAccountInformation", response)
        

    
        
        
        
        
        
    
        
                
    def test_10001_RetrieveAccountStatusWithNonTokenizedRequest(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("account_verification_input.account_verification_reference", "100019189")
        map.set("account_verification_input.first_name", "Dicky")
        map.set("account_verification_input.last_name", "Bird")
        map.set("account_verification_input.account_uri", "pan:5102589999999798;exp=2095-12;cvc=234")
        map.set("account_verification_input.address.line1", "1 Main Street")
        map.set("account_verification_input.address.line2", "Appartment 11")
        map.set("account_verification_input.address.city", "HAGEN")
        map.set("account_verification_input.address.country_subdivision", "MT")
        map.set("account_verification_input.address.postal_code", "63368-3784")
        map.set("account_verification_input.address.country", "USA")
        
        
        response = AccountVerification.read(map)

        ignoreAsserts = []
        ignoreAsserts.append("account_verification.request_id")
        
        self.customAssertEqual(ignoreAsserts, "account_verification.request_id", response.get("account_verification.request_id"),"rqst_C6A5-C986-AC0D-1ADB")
        self.customAssertEqual(ignoreAsserts, "account_verification.resource_type", response.get("account_verification.resource_type"),"account_verification")
        self.customAssertEqual(ignoreAsserts, "account_verification.address_status", response.get("account_verification.address_status"),"NOT_MATCHED")
        self.customAssertEqual(ignoreAsserts, "account_verification.postal_code_status", response.get("account_verification.postal_code_status"),"MATCHED")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_status", response.get("account_verification.cvc_status"),"MATCHED")
        self.customAssertEqual(ignoreAsserts, "account_verification.avs_response_code", response.get("account_verification.avs_response_code"),"W")
        self.customAssertEqual(ignoreAsserts, "account_verification.avs_response_desc", response.get("account_verification.avs_response_desc"),"For U.S. addresses, nine-digit postal code matches, address does not; for address outside the U.S., postal code matches, address does not.")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_resp_code", response.get("account_verification.cvc_resp_code"),"M")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_resp_desc", response.get("account_verification.cvc_resp_desc"),"CVC2/CSC match")
        

        BaseTest.putResponse("RetrieveAccountStatusWithNonTokenizedRequest", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_19001_RegisterConsumer(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumer.consumer_reference", "ref_069799277430117605")
        map.set("consumer.first_name", "Jane")
        map.set("consumer.middle_name", "Tyler")
        map.set("consumer.last_name", "Smith")
        map.set("consumer.nationality", "USA")
        map.set("consumer.date_of_birth", "1999-12-30")
        map.set("consumer.address.line1", "1 Main Street")
        map.set("consumer.address.line2", "Apartment 9")
        map.set("consumer.address.city", "OFallon")
        map.set("consumer.address.country_subdivision", "MO")
        map.set("consumer.address.postal_code", "63368")
        map.set("consumer.address.country", "USA")
        map.set("consumer.primary_phone", "11234567890")
        map.set("consumer.primary_email", "Jane.Smith123@abcmail.com")
        map.set("consumer.account.default_sending", "true")
        map.set("consumer.account.default_receiving", "true")
        map.set("consumer.account.account_reference", "ref_191255798709562798")
        map.set("consumer.account.label", "JaneMC")
        map.set("consumer.account.account_uri", "pan:5432123456789012;exp=2017-02;cvc=123")
        map.set("consumer.account.name_on_account", "Jane Tyler Smith")
        map.set("consumer.account.address.line1", "1 Main St")
        map.set("consumer.account.address.line2", "Apartment 9")
        map.set("consumer.account.address.city", "OFallon")
        map.set("consumer.account.address.country_subdivision", "MO")
        map.set("consumer.account.address.postal_code", "63368")
        map.set("consumer.account.address.country", "USA")
        
        
        response = Consumer.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("consumer.id")
        ignoreAsserts.append("consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumer.preferences.default_accounts.receiving")
        
        self.customAssertEqual(ignoreAsserts, "consumer.id", response.get("consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumer.resource_type", response.get("consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumer.consumer_reference", response.get("consumer.consumer_reference"),"ref_069799277430117605")
        self.customAssertEqual(ignoreAsserts, "consumer.first_name", response.get("consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumer.middle_name", response.get("consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumer.last_name", response.get("consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumer.nationality", response.get("consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.date_of_birth", response.get("consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line1", response.get("consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line2", response.get("consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumer.address.city", response.get("consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country_subdivision", response.get("consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumer.address.postal_code", response.get("consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country", response.get("consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_phone", response.get("consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_email", response.get("consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.sending", response.get("consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.receiving", response.get("consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("RegisterConsumer", response)
        

    
        
        
        
        
        
        
    
        
        
        
        
        
                
    def test_20001_RetrieveConsumer(self):
        

        

        id = ""
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = Consumer.readByID(id,map)

        ignoreAsserts = []
        ignoreAsserts.append("consumer.id")
        ignoreAsserts.append("consumer.consumer_reference")
        ignoreAsserts.append("consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumer.preferences.default_accounts.receiving")
        
        self.customAssertEqual(ignoreAsserts, "consumer.id", response.get("consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumer.resource_type", response.get("consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumer.consumer_reference", response.get("consumer.consumer_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "consumer.first_name", response.get("consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumer.middle_name", response.get("consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumer.last_name", response.get("consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumer.nationality", response.get("consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.date_of_birth", response.get("consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line1", response.get("consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line2", response.get("consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumer.address.city", response.get("consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country_subdivision", response.get("consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumer.address.postal_code", response.get("consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country", response.get("consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_phone", response.get("consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_email", response.get("consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.sending", response.get("consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.receiving", response.get("consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("RetrieveConsumer", response)
        

    
        
        
    
        
                
    def test_20040_AddConsumerContactId(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("contact_id.contact_id_uri", "tel:58455626637")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = ConsumerContactID.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("contact_id.id")
        ignoreAsserts.append("contact_id.contact_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "contact_id.id", response.get("contact_id.id"),"cntc_3747dskr4hrfjjd")
        self.customAssertEqual(ignoreAsserts, "contact_id.resource_type", response.get("contact_id.resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contact_id.contact_id_uri", response.get("contact_id.contact_id_uri"),"tel:58455626637")
        

        BaseTest.putResponse("AddConsumerContactId", response)
        

    
        
        
        
        
        
        
    
        
        
        
        
        
        
                
    def test_21001_SearchConsumer_ConsumerReference(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("ref", "ref_20160823192231787")
        
        map.set("ref", BaseTest.resolveResponseValue("RegisterConsumer.consumer.consumer_reference"));
        
        response = Consumer.listByReferenceOrContactID(map)

        ignoreAsserts = []
        ignoreAsserts.append("consumers.data.consumer.id")
        ignoreAsserts.append("consumers.data.consumer.consumer_reference")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.receiving")
        
        self.customAssertEqual(ignoreAsserts, "consumers.resource_type", response.get("consumers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "consumers.item_count", response.get("consumers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.id", response.get("consumers.data.consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.resource_type", response.get("consumers.data.consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.consumer_reference", response.get("consumers.data.consumer.consumer_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.first_name", response.get("consumers.data.consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.middle_name", response.get("consumers.data.consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.last_name", response.get("consumers.data.consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.nationality", response.get("consumers.data.consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.date_of_birth", response.get("consumers.data.consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line1", response.get("consumers.data.consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line2", response.get("consumers.data.consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.city", response.get("consumers.data.consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country_subdivision", response.get("consumers.data.consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.postal_code", response.get("consumers.data.consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country", response.get("consumers.data.consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_phone", response.get("consumers.data.consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_email", response.get("consumers.data.consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.sending", response.get("consumers.data.consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.receiving", response.get("consumers.data.consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("SearchConsumer_ConsumerReference", response)
        

    
        
    
        
        
        
        
        
        
                
    def test_21002_SearchConsumer_Contact_ID_URI(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("contact_id_uri", "tel:12125556649")
        
        map.set("contact_id_uri", BaseTest.resolveResponseValue("AddConsumerContactId.contact_id.contact_id_uri"));
        
        response = Consumer.listByReferenceOrContactID(map)

        ignoreAsserts = []
        ignoreAsserts.append("consumers.data.consumer.id")
        ignoreAsserts.append("consumers.data.consumer.consumer_reference")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.receiving")
        ignoreAsserts.append("consumers.item_count")
        
        self.customAssertEqual(ignoreAsserts, "consumers.resource_type", response.get("consumers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "consumers.item_count", response.get("consumers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.id", response.get("consumers.data.consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.resource_type", response.get("consumers.data.consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.consumer_reference", response.get("consumers.data.consumer.consumer_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.first_name", response.get("consumers.data.consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.middle_name", response.get("consumers.data.consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.last_name", response.get("consumers.data.consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.nationality", response.get("consumers.data.consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.date_of_birth", response.get("consumers.data.consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line1", response.get("consumers.data.consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line2", response.get("consumers.data.consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.city", response.get("consumers.data.consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country_subdivision", response.get("consumers.data.consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.postal_code", response.get("consumers.data.consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country", response.get("consumers.data.consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_phone", response.get("consumers.data.consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_email", response.get("consumers.data.consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.sending", response.get("consumers.data.consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.receiving", response.get("consumers.data.consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("SearchConsumer_Contact_ID_URI", response)
        

    
        
    
        
                
    def test_22001_SearchConsumers_ConsumerReference(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumer.search_by", "consumer_reference")
        map.set("consumer.search_value", "ref_20160823193804233")
        
        map.set("consumer.search_value", BaseTest.resolveResponseValue("RegisterConsumer.consumer.consumer_reference"));
        
        response = Consumer.listByReferenceContactIDOrGovernmentID(map)

        ignoreAsserts = []
        ignoreAsserts.append("consumers.data.consumer.id")
        ignoreAsserts.append("consumers.data.consumer.consumer_reference")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.receiving")
        
        self.customAssertEqual(ignoreAsserts, "consumers.resource_type", response.get("consumers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "consumers.item_count", response.get("consumers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.id", response.get("consumers.data.consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.resource_type", response.get("consumers.data.consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.consumer_reference", response.get("consumers.data.consumer.consumer_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.first_name", response.get("consumers.data.consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.middle_name", response.get("consumers.data.consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.last_name", response.get("consumers.data.consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.nationality", response.get("consumers.data.consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.date_of_birth", response.get("consumers.data.consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line1", response.get("consumers.data.consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line2", response.get("consumers.data.consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.city", response.get("consumers.data.consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country_subdivision", response.get("consumers.data.consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.postal_code", response.get("consumers.data.consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country", response.get("consumers.data.consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_phone", response.get("consumers.data.consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_email", response.get("consumers.data.consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.sending", response.get("consumers.data.consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.receiving", response.get("consumers.data.consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("SearchConsumers_ConsumerReference", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_22002_SearchConsumers_Contact_ID_URI(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumer.search_by", "contact_id_uri")
        map.set("consumer.search_value", "tel:12125556649")
        
        map.set("consumer.search_value", BaseTest.resolveResponseValue("AddConsumerContactId.contact_id.contact_id_uri"));
        
        response = Consumer.listByReferenceContactIDOrGovernmentID(map)

        ignoreAsserts = []
        ignoreAsserts.append("consumers.data.consumer.id")
        ignoreAsserts.append("consumers.data.consumer.consumer_reference")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumers.data.consumer.preferences.default_accounts.receiving")
        
        self.customAssertEqual(ignoreAsserts, "consumers.resource_type", response.get("consumers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "consumers.item_count", response.get("consumers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.id", response.get("consumers.data.consumer.id"),"cns_f21tg68mh89c376h")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.resource_type", response.get("consumers.data.consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.consumer_reference", response.get("consumers.data.consumer.consumer_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.first_name", response.get("consumers.data.consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.middle_name", response.get("consumers.data.consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.last_name", response.get("consumers.data.consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.nationality", response.get("consumers.data.consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.date_of_birth", response.get("consumers.data.consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line1", response.get("consumers.data.consumer.address.line1"),"1 Main Street")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.line2", response.get("consumers.data.consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.city", response.get("consumers.data.consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country_subdivision", response.get("consumers.data.consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.postal_code", response.get("consumers.data.consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.address.country", response.get("consumers.data.consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_phone", response.get("consumers.data.consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.primary_email", response.get("consumers.data.consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.sending", response.get("consumers.data.consumer.preferences.default_accounts.sending"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "consumers.data.consumer.preferences.default_accounts.receiving", response.get("consumers.data.consumer.preferences.default_accounts.receiving"),"acct_mk32k324mg6wn19x")
        

        BaseTest.putResponse("SearchConsumers_Contact_ID_URI", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_25002_AddConsumerAccountForDisb(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("account.account_reference", "ref_25217791070007236")
        map.set("account.label", "JaneMC")
        map.set("account.account_uri", "pan:5013040000000018;exp=2017-05;cvc=123")
        map.set("account.name_on_account", "Jane Tyler Smith")
        map.set("account.address.line1", "1 Main St")
        map.set("account.address.line2", "Apartment 9")
        map.set("account.address.city", "OFallon")
        map.set("account.address.country_subdivision", "MO")
        map.set("account.address.postal_code", "63368")
        map.set("account.address.country", "USA")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = ConsumerAccount.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("account.id")
        ignoreAsserts.append("account.account_reference")
        ignoreAsserts.append("account.account_uri")
        
        self.customAssertEqual(ignoreAsserts, "account.id", response.get("account.id"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "account.resource_type", response.get("account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "account.account_reference", response.get("account.account_reference"),"ref_25217791070007236")
        self.customAssertEqual(ignoreAsserts, "account.label", response.get("account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "account.account_uri", response.get("account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "account.brand", response.get("account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account.name_on_account", response.get("account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "account.address.line1", response.get("account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "account.address.line2", response.get("account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "account.address.city", response.get("account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "account.address.country_subdivision", response.get("account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "account.address.postal_code", response.get("account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "account.address.country", response.get("account.address.country"),"USA")
        

        BaseTest.putResponse("AddConsumerAccountForDisb", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_30001_AddConsumerAccount(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("account.account_reference", "ref_069799277430117605")
        map.set("account.label", "JaneMC")
        map.set("account.account_uri", "pan:5432123456789012;exp=2017-02;cvc=123")
        map.set("account.name_on_account", "Jane Tyler Smith")
        map.set("account.address.line1", "1 Main St")
        map.set("account.address.line2", "Apartment 9")
        map.set("account.address.city", "OFallon")
        map.set("account.address.country_subdivision", "MO")
        map.set("account.address.postal_code", "63368")
        map.set("account.address.country", "USA")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = ConsumerAccount.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("account.id")
        ignoreAsserts.append("account.account_reference")
        ignoreAsserts.append("account.account_uri")
        
        self.customAssertEqual(ignoreAsserts, "account.id", response.get("account.id"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "account.resource_type", response.get("account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "account.account_reference", response.get("account.account_reference"),"ref_069799277430117605")
        self.customAssertEqual(ignoreAsserts, "account.label", response.get("account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "account.account_uri", response.get("account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "account.brand", response.get("account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account.name_on_account", response.get("account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "account.address.line1", response.get("account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "account.address.line2", response.get("account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "account.address.city", response.get("account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "account.address.country_subdivision", response.get("account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "account.address.postal_code", response.get("account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "account.address.country", response.get("account.address.country"),"USA")
        

        BaseTest.putResponse("AddConsumerAccount", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_30002_RetrieveAccountStatusWithTokenizedRequest(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("account_verification_input.account_verification_reference", "100020316")
        map.set("account_verification_input.account_uri", "acct-ref:ref_01917852970663931")
        
        map.set("account_verification_input.account_uri", "acct-ref:"+BaseTest.resolveResponseValue("AddConsumerAccountForDisb.account.account_reference"));
        
        response = AccountVerification.read(map)

        ignoreAsserts = []
        ignoreAsserts.append("account_verification.request_id")
        
        self.customAssertEqual(ignoreAsserts, "account_verification.request_id", response.get("account_verification.request_id"),"rqst_7718-84A6-9888-DF87")
        self.customAssertEqual(ignoreAsserts, "account_verification.resource_type", response.get("account_verification.resource_type"),"account_verification")
        self.customAssertEqual(ignoreAsserts, "account_verification.address_status", response.get("account_verification.address_status"),"NOT_MATCHED")
        self.customAssertEqual(ignoreAsserts, "account_verification.postal_code_status", response.get("account_verification.postal_code_status"),"MATCHED")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_status", response.get("account_verification.cvc_status"),"NOT_VERIFIED")
        self.customAssertEqual(ignoreAsserts, "account_verification.avs_response_code", response.get("account_verification.avs_response_code"),"Z")
        self.customAssertEqual(ignoreAsserts, "account_verification.avs_response_desc", response.get("account_verification.avs_response_desc"),"For U.S. addresses, five-digit postal code matches, address does not.")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_resp_code", response.get("account_verification.cvc_resp_code"),"P")
        self.customAssertEqual(ignoreAsserts, "account_verification.cvc_resp_desc", response.get("account_verification.cvc_resp_desc"),"Not processed")
        

        BaseTest.putResponse("RetrieveAccountStatusWithTokenizedRequest", response)
        

    
        
        
        
        
        
        
    
        
        
        
        
        
                
    def test_31001_RetrieveConsumerAccount(self):
        

        

        id = ""
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("accountId", "acct_mk32k324mg6wn19x")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("accountId", BaseTest.resolveResponseValue("AddConsumerAccount.account.id"));
        
        response = ConsumerAccount.readByID(id,map)

        ignoreAsserts = []
        ignoreAsserts.append("account.id")
        ignoreAsserts.append("account.account_reference")
        ignoreAsserts.append("account.account_uri")
        
        self.customAssertEqual(ignoreAsserts, "account.id", response.get("account.id"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "account.resource_type", response.get("account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "account.account_reference", response.get("account.account_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "account.label", response.get("account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "account.account_uri", response.get("account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "account.brand", response.get("account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account.name_on_account", response.get("account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "account.address.line1", response.get("account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "account.address.line2", response.get("account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "account.address.city", response.get("account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "account.address.country_subdivision", response.get("account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "account.address.postal_code", response.get("account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "account.address.country", response.get("account.address.country"),"USA")
        

        BaseTest.putResponse("RetrieveConsumerAccount", response)
        

    
        
        
    
        
        
        
        
        
        
                
    def test_32001_RetrieveConsumerAccounts(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("ref", "ref_20160823193804233")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("ref", BaseTest.resolveResponseValue("AddConsumerAccount.account.account_reference"));
        
        response = ConsumerAccount.listAll(map)

        ignoreAsserts = []
        ignoreAsserts.append("accounts.data.account.id")
        ignoreAsserts.append("accounts.data.account.account_reference")
        ignoreAsserts.append("accounts.data.account.account_uri")
        
        self.customAssertEqual(ignoreAsserts, "accounts.resource_type", response.get("accounts.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "accounts.item_count", response.get("accounts.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.id", response.get("accounts.data.account.id"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.resource_type", response.get("accounts.data.account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.account_reference", response.get("accounts.data.account.account_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.label", response.get("accounts.data.account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.account_uri", response.get("accounts.data.account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.brand", response.get("accounts.data.account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.name_on_account", response.get("accounts.data.account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.line1", response.get("accounts.data.account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.line2", response.get("accounts.data.account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.city", response.get("accounts.data.account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.country_subdivision", response.get("accounts.data.account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.postal_code", response.get("accounts.data.account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "accounts.data.account.address.country", response.get("accounts.data.account.address.country"),"USA")
        

        BaseTest.putResponse("RetrieveConsumerAccounts", response)
        

    
        
    
        
                
    def test_32141_CreatePayment_NON_TOKENIZED(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("payment_transfer.transfer_reference", "40011187719687565298718")
        map.set("payment_transfer.payment_type", "P2P")
        map.set("payment_transfer.funding_source[0]", "CREDIT")
        map.set("payment_transfer.funding_source[1]", "DEBIT")
        map.set("payment_transfer.amount", "1800")
        map.set("payment_transfer.currency", "USD")
        map.set("payment_transfer.sender_account_uri", "pan:5013040000000018;exp=2017-08;cvc=123")
        map.set("payment_transfer.sender.first_name", "John")
        map.set("payment_transfer.sender.middle_name", "Tyler")
        map.set("payment_transfer.sender.last_name", "Jones")
        map.set("payment_transfer.sender.nationality", "USA")
        map.set("payment_transfer.sender.date_of_birth", "1994-05-21")
        map.set("payment_transfer.sender.address.line1", "21 Broadway")
        map.set("payment_transfer.sender.address.line2", "Apartment A-6")
        map.set("payment_transfer.sender.address.city", "OFallon")
        map.set("payment_transfer.sender.address.country_subdivision", "MO")
        map.set("payment_transfer.sender.address.postal_code", "63368")
        map.set("payment_transfer.sender.address.country", "USA")
        map.set("payment_transfer.sender.phone", "11234565555")
        map.set("payment_transfer.sender.email", "John.Jones123@abcmail.com")
        map.set("payment_transfer.sender.government_ids.government_id_uri", "ppn:123456789;expiration-date=2019-05-27;issue-date=2011-07-12;issuing-country=USA;issuing-place=OFallon")
        map.set("payment_transfer.recipient_account_uri", "pan:5013040000000018;exp=2017-08;cvc=123")
        map.set("payment_transfer.recipient.first_name", "Jane")
        map.set("payment_transfer.recipient.middle_name", "Tyler")
        map.set("payment_transfer.recipient.last_name", "Smith")
        map.set("payment_transfer.recipient.nationality", "USA")
        map.set("payment_transfer.recipient.date_of_birth", "1999-12-30")
        map.set("payment_transfer.recipient.address.line1", "1 Main St")
        map.set("payment_transfer.recipient.address.line2", "Apartment 9")
        map.set("payment_transfer.recipient.address.city", "OFallon")
        map.set("payment_transfer.recipient.address.country_subdivision", "MO")
        map.set("payment_transfer.recipient.address.postal_code", "63368")
        map.set("payment_transfer.recipient.address.country", "USA")
        map.set("payment_transfer.recipient.phone", "11234567890")
        map.set("payment_transfer.recipient.email", "John.Jones123@abcmail.com")
        map.set("payment_transfer.recipient.government_ids.government_id_uri", "ppn:123456789;expiration-date=2019-05-27;issue-date=2011-07-12;issuing-country=USA;issuing-place=OFallon")
        map.set("payment_transfer.payment_origination_country", "USA")
        map.set("payment_transfer.sanction_screening_override", " false ")
        map.set("payment_transfer.reconciliation_data.custom_field[0].name", "ABC")
        map.set("payment_transfer.reconciliation_data.custom_field[0].value", "123")
        map.set("payment_transfer.reconciliation_data.custom_field[1].name", "DEF")
        map.set("payment_transfer.reconciliation_data.custom_field[1].value", "456")
        map.set("payment_transfer.reconciliation_data.custom_field[2].name", "GHI")
        map.set("payment_transfer.reconciliation_data.custom_field[2].value", "789")
        map.set("payment_transfer.statement_descriptor", "TST*THANKYOU")
        map.set("payment_transfer.channel", "KIOSK")
        map.set("payment_transfer.text", "funding_source")
        
        map.set("payment_transfer.statement_descriptor", BaseTest.resolveResponseValue("val:CLA*THANK YOU"));
        
        response = PaymentTransfer.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("payment_transfer.transfer_reference")
        ignoreAsserts.append("payment_transfer.amount")
        ignoreAsserts.append("payment_transfer.currency")
        ignoreAsserts.append("transfer.statement_descriptor")
        ignoreAsserts.append("transfer.id")
        ignoreAsserts.append("payment_transfer.transfer_reference")
        ignoreAsserts.append("payment_transfer.amount")
        ignoreAsserts.append("payment_transfer.currency")
        ignoreAsserts.append("payment_transfer.statement_descriptor")
        ignoreAsserts.append("transfer.created")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfer.status_timestamp")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfer.sender.email")
        ignoreAsserts.append("transfer.recipient.email")
        ignoreAsserts.append("payment_transfer.recipient.government_ids")
        ignoreAsserts.append("payment_transfer.sender.government_ids")
        ignoreAsserts.append("payment_transfer.sender.government_ids.government_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "transfer.id", response.get("transfer.id"),"trn_MQTGry0D_TGe8QTrWj4LtaydUUWM")
        self.customAssertEqual(ignoreAsserts, "transfer.resource_type", response.get("transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_reference", response.get("transfer.transfer_reference"),"40011187719687565298718")
        self.customAssertEqual(ignoreAsserts, "transfer.payment_type", response.get("transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfer.sender_account_uri", response.get("transfer.sender_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.first_name", response.get("transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.middle_name", response.get("transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.last_name", response.get("transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.nationality", response.get("transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.date_of_birth", response.get("transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line1", response.get("transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line2", response.get("transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.city", response.get("transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country_subdivision", response.get("transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.postal_code", response.get("transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country", response.get("transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.phone", response.get("transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.email", response.get("transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient_account_uri", response.get("transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.first_name", response.get("transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.middle_name", response.get("transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.last_name", response.get("transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.nationality", response.get("transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.date_of_birth", response.get("transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line1", response.get("transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line2", response.get("transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.city", response.get("transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country_subdivision", response.get("transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.postal_code", response.get("transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country", response.get("transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.phone", response.get("transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.email", response.get("transfer.recipient.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.value", response.get("transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.currency", response.get("transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.created", response.get("transfer.created"),"2016-08-29T01:07:37-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.resource_type", response.get("transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.item_count", response.get("transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.id", response.get("transfer.transaction_history.data.transaction.id"),"txn_SVDvtQk1mKcJefExHKpvVeLctXvJ")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.resource_type", response.get("transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.account_uri", response.get("transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network", response.get("transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.funds_availability", response.get("transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.type", response.get("transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.create_timestamp", response.get("transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T01:07:37-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status", response.get("transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_reason", response.get("transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_timestamp", response.get("transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:07:37-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].name", response.get("transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].value", response.get("transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].name", response.get("transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].value", response.get("transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].name", response.get("transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].value", response.get("transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfer.statement_descriptor", response.get("transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfer.channel", response.get("transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfer.status", response.get("transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.status_timestamp", response.get("transfer.status_timestamp"),"2016-08-29T01:07:37-05:00")
        

        BaseTest.putResponse("CreatePayment_NON_TOKENIZED", response)
        

    
        
        
        
        
        
        
    
        
                
    def test_32142_CreatePayment_TOKENIZED(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("payment_transfer.transfer_reference", "40021187719687565298718")
        map.set("payment_transfer.payment_type", "P2P")
        map.set("payment_transfer.funding_source[0]", "CREDIT")
        map.set("payment_transfer.funding_source[1]", "DEBIT")
        map.set("payment_transfer.amount", "1800")
        map.set("payment_transfer.currency", "USD")
        map.set("payment_transfer.sender_account_uri", "acct-ref:ref_20160407070850915")
        map.set("payment_transfer.sender.first_name", "John")
        map.set("payment_transfer.sender.middle_name", "Tyler")
        map.set("payment_transfer.sender.last_name", "Jones")
        map.set("payment_transfer.sender.nationality", "USA")
        map.set("payment_transfer.sender.date_of_birth", "1994-05-21")
        map.set("payment_transfer.sender.address.line1", "21 Broadway")
        map.set("payment_transfer.sender.address.line2", "Apartment A-6")
        map.set("payment_transfer.sender.address.city", "OFallon")
        map.set("payment_transfer.sender.address.country_subdivision", "MO")
        map.set("payment_transfer.sender.address.postal_code", "63368")
        map.set("payment_transfer.sender.address.country", "USA")
        map.set("payment_transfer.sender.phone", "11234565555")
        map.set("payment_transfer.sender.email", "John.Jones123@abcmail.com")
        map.set("payment_transfer.recipient_account_uri", "pan:5013040000000018;exp=2017-08;cvc=123")
        map.set("payment_transfer.recipient.first_name", "Jane")
        map.set("payment_transfer.recipient.middle_name", "Tyler")
        map.set("payment_transfer.recipient.last_name", "Smith")
        map.set("payment_transfer.recipient.nationality", "USA")
        map.set("payment_transfer.recipient.date_of_birth", "1999-12-30")
        map.set("payment_transfer.recipient.address.line1", "1 Main St")
        map.set("payment_transfer.recipient.address.line2", "Apartment 9")
        map.set("payment_transfer.recipient.address.city", "OFallon")
        map.set("payment_transfer.recipient.address.country_subdivision", "MO")
        map.set("payment_transfer.recipient.address.postal_code", "63368")
        map.set("payment_transfer.recipient.address.country", "USA")
        map.set("payment_transfer.recipient.phone", "11234567890")
        map.set("payment_transfer.recipient.email", "Jane.Smith123@abcmail.com")
        map.set("payment_transfer.payment_origination_country", "USA")
        map.set("payment_transfer.sanction_screening_override", " false ")
        map.set("payment_transfer.reconciliation_data.custom_field[0].name", "ABC")
        map.set("payment_transfer.reconciliation_data.custom_field[0].value", "123")
        map.set("payment_transfer.reconciliation_data.custom_field[1].name", "DEF")
        map.set("payment_transfer.reconciliation_data.custom_field[1].value", "456")
        map.set("payment_transfer.reconciliation_data.custom_field[2].name", "GHI")
        map.set("payment_transfer.reconciliation_data.custom_field[2].value", "789")
        map.set("payment_transfer.statement_descriptor", "TST*THANKYOU")
        map.set("payment_transfer.channel", "KIOSK")
        map.set("payment_transfer.text", "funding_source")
        
        map.set("payment_transfer.sender_account_uri", "acct-ref:"+BaseTest.resolveResponseValue("AddConsumerAccount.account.account_reference"));
        map.set("payment_transfer.statement_descriptor", BaseTest.resolveResponseValue("val:CLA*THANK YOU"));
        
        response = PaymentTransfer.create(map)

        ignoreAsserts = []
        ignoreAsserts.append("transfer.id")
        ignoreAsserts.append("transfer.created")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfer.status_timestamp")
        ignoreAsserts.append("transfer.sender.email")
        ignoreAsserts.append("transfer.recipient.email")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfer.sender_account_uri")
        ignoreAsserts.append("payment_transfer.recipient.government_ids")
        ignoreAsserts.append("payment_transfer.sender.government_ids")
        ignoreAsserts.append("payment_transfer.sender.government_ids.government_id_uri")
        ignoreAsserts.append("transfer.statement_descriptor")
        
        self.customAssertEqual(ignoreAsserts, "transfer.id", response.get("transfer.id"),"trn_4MMUC7147Vamd1IVt77DV0d-mIZr")
        self.customAssertEqual(ignoreAsserts, "transfer.resource_type", response.get("transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_reference", response.get("transfer.transfer_reference"),"40021187719687565298718")
        self.customAssertEqual(ignoreAsserts, "transfer.payment_type", response.get("transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfer.sender_account_uri", response.get("transfer.sender_account_uri"),"acct-ref:ref_20160407070850915")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.first_name", response.get("transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.middle_name", response.get("transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.last_name", response.get("transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.nationality", response.get("transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.date_of_birth", response.get("transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line1", response.get("transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line2", response.get("transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.city", response.get("transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country_subdivision", response.get("transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.postal_code", response.get("transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country", response.get("transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.phone", response.get("transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.email", response.get("transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient_account_uri", response.get("transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.first_name", response.get("transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.middle_name", response.get("transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.last_name", response.get("transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.nationality", response.get("transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.date_of_birth", response.get("transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line1", response.get("transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line2", response.get("transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.city", response.get("transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country_subdivision", response.get("transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.postal_code", response.get("transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country", response.get("transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.phone", response.get("transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.email", response.get("transfer.recipient.email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.value", response.get("transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.currency", response.get("transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.created", response.get("transfer.created"),"2016-08-29T01:11:02-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.resource_type", response.get("transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.item_count", response.get("transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.id", response.get("transfer.transaction_history.data.transaction.id"),"txn_S7hjCOKzzkSzeCTS7g-Fdq0_drCD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.resource_type", response.get("transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.account_uri", response.get("transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network", response.get("transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.funds_availability", response.get("transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.type", response.get("transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.create_timestamp", response.get("transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T01:11:02-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status", response.get("transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_reason", response.get("transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_timestamp", response.get("transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:11:02-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].name", response.get("transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].value", response.get("transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].name", response.get("transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].value", response.get("transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].name", response.get("transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].value", response.get("transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfer.statement_descriptor", response.get("transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfer.channel", response.get("transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfer.status", response.get("transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.status_timestamp", response.get("transfer.status_timestamp"),"2016-08-29T01:11:02-05:00")
        

        BaseTest.putResponse("CreatePayment_TOKENIZED", response)
        

    
        
        
        
        
        
        
    
        
        
        
        
        
                
    def test_32151_GetTransferById_NON_TOKENIZED(self):
        

        

        id = ""
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("transferId", "trn_MQTGry0D_TGe8QTrWj4LtaydUUWM")
        
        map.set("transferId", BaseTest.resolveResponseValue("CreatePayment_NON_TOKENIZED.transfer.id"));
        
        response = PaymentTransfer.readByID(id,map)

        ignoreAsserts = []
        ignoreAsserts.append("transfer.transfer_reference")
        ignoreAsserts.append("transfer.id")
        ignoreAsserts.append("transfer.created")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfer.status_timestamp")
        ignoreAsserts.append("transfer.sender.email")
        ignoreAsserts.append("transfer.recipient.email")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfer.statement_descriptor")
        
        self.customAssertEqual(ignoreAsserts, "transfer.id", response.get("transfer.id"),"trn_MQTGry0D_TGe8QTrWj4LtaydUUWM")
        self.customAssertEqual(ignoreAsserts, "transfer.resource_type", response.get("transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_reference", response.get("transfer.transfer_reference"),"TRNREF_20160829130404970")
        self.customAssertEqual(ignoreAsserts, "transfer.payment_type", response.get("transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfer.sender_account_uri", response.get("transfer.sender_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.first_name", response.get("transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.middle_name", response.get("transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.last_name", response.get("transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.nationality", response.get("transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.date_of_birth", response.get("transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line1", response.get("transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line2", response.get("transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.city", response.get("transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country_subdivision", response.get("transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.postal_code", response.get("transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country", response.get("transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.phone", response.get("transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.email", response.get("transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.payment_origination_country", response.get("transfer.payment_origination_country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient_account_uri", response.get("transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.first_name", response.get("transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.middle_name", response.get("transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.last_name", response.get("transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.nationality", response.get("transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.date_of_birth", response.get("transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line1", response.get("transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line2", response.get("transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.city", response.get("transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country_subdivision", response.get("transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.postal_code", response.get("transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country", response.get("transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.phone", response.get("transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.email", response.get("transfer.recipient.email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.value", response.get("transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.currency", response.get("transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.created", response.get("transfer.created"),"2016-08-29T08:07:37.282-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.resource_type", response.get("transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.item_count", response.get("transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.id", response.get("transfer.transaction_history.data.transaction.id"),"txn_SVDvtQk1mKcJefExHKpvVeLctXvJ")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.resource_type", response.get("transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.account_uri", response.get("transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network", response.get("transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network_status_code", response.get("transfer.transaction_history.data.transaction.network_status_code"),"00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network_status_description", response.get("transfer.transaction_history.data.transaction.network_status_description"),"Approved or completed successfully")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.funds_availability", response.get("transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.type", response.get("transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.create_timestamp", response.get("transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T08:07:37.288-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status", response.get("transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_reason", response.get("transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_timestamp", response.get("transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:07:37-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].name", response.get("transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].value", response.get("transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].name", response.get("transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].value", response.get("transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].name", response.get("transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].value", response.get("transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfer.statement_descriptor", response.get("transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfer.channel", response.get("transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfer.status", response.get("transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.status_timestamp", response.get("transfer.status_timestamp"),"2016-08-29T08:07:37.374-05:00")
        

        BaseTest.putResponse("GetTransferById_NON_TOKENIZED", response)
        

    
        
        
    
        
        
        
        
        
                
    def test_32152_GetTransferById_TOKENIZED(self):
        

        

        id = ""
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("transferId", "trn_4MMUC7147Vamd1IVt77DV0d-mIZr")
        
        map.set("transferId", BaseTest.resolveResponseValue("CreatePayment_TOKENIZED.transfer.id"));
        
        response = PaymentTransfer.readByID(id,map)

        ignoreAsserts = []
        ignoreAsserts.append("transfer.transfer_reference")
        ignoreAsserts.append("transfer.id")
        ignoreAsserts.append("transfer.created")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfer.status_timestamp")
        ignoreAsserts.append("transfer.sender.email")
        ignoreAsserts.append("transfer.recipient.email")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfer.sender_account_uri")
        ignoreAsserts.append("transfer.statement_descriptor")
        
        self.customAssertEqual(ignoreAsserts, "transfer.id", response.get("transfer.id"),"trn_4MMUC7147Vamd1IVt77DV0d-mIZr")
        self.customAssertEqual(ignoreAsserts, "transfer.resource_type", response.get("transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_reference", response.get("transfer.transfer_reference"),"TRNREF_20160829130737009")
        self.customAssertEqual(ignoreAsserts, "transfer.payment_type", response.get("transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfer.sender_account_uri", response.get("transfer.sender_account_uri"),"acct-ref:ref_20160407070850915")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.first_name", response.get("transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.middle_name", response.get("transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.last_name", response.get("transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.nationality", response.get("transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.date_of_birth", response.get("transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line1", response.get("transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.line2", response.get("transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.city", response.get("transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country_subdivision", response.get("transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.postal_code", response.get("transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.address.country", response.get("transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.phone", response.get("transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfer.sender.email", response.get("transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient_account_uri", response.get("transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.first_name", response.get("transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.middle_name", response.get("transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.last_name", response.get("transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.nationality", response.get("transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.date_of_birth", response.get("transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line1", response.get("transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.line2", response.get("transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.city", response.get("transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country_subdivision", response.get("transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.postal_code", response.get("transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.address.country", response.get("transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.phone", response.get("transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfer.recipient.email", response.get("transfer.recipient.email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.value", response.get("transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transfer_amount.currency", response.get("transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.created", response.get("transfer.created"),"2016-08-29T08:11:02.799-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.resource_type", response.get("transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.item_count", response.get("transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.id", response.get("transfer.transaction_history.data.transaction.id"),"txn_S7hjCOKzzkSzeCTS7g-Fdq0_drCD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.resource_type", response.get("transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.account_uri", response.get("transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network", response.get("transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network_status_code", response.get("transfer.transaction_history.data.transaction.network_status_code"),"00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.network_status_description", response.get("transfer.transaction_history.data.transaction.network_status_description"),"Approved or completed successfully")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.funds_availability", response.get("transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.type", response.get("transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.create_timestamp", response.get("transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T08:11:02.805-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status", response.get("transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_reason", response.get("transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.status_timestamp", response.get("transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:11:02-05:00")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].name", response.get("transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[0].value", response.get("transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].name", response.get("transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[1].value", response.get("transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].name", response.get("transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfer.reconciliation_data.custom_field[2].value", response.get("transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfer.statement_descriptor", response.get("transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfer.channel", response.get("transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfer.status", response.get("transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfer.status_timestamp", response.get("transfer.status_timestamp"),"2016-08-29T08:11:02.895-05:00")
        

        BaseTest.putResponse("GetTransferById_TOKENIZED", response)
        

    
        
        
    
        
        
        
        
        
        
                
    def test_32161_GetTransferByRef_NON_TOKENIZED(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("ref", "TRNREF_20160829130404970")
        
        map.set("ref", BaseTest.resolveResponseValue("CreatePayment_NON_TOKENIZED.transfer.transfer_reference"));
        
        response = PaymentTransfer.readByReference(map)

        ignoreAsserts = []
        ignoreAsserts.append("transfers.data.transfer.transfer_reference")
        ignoreAsserts.append("transfers.data.transfer.id")
        ignoreAsserts.append("transfers.data.transfer.created")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfers.data.transfer.status_timestamp")
        ignoreAsserts.append("transfers.data.transfer.sender.email")
        ignoreAsserts.append("transfers.data.transfer.recipient.email")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfers.data.transfer.statement_descriptor")
        
        self.customAssertEqual(ignoreAsserts, "transfers.resource_type", response.get("transfers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfers.item_count", response.get("transfers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.id", response.get("transfers.data.transfer.id"),"trn_MQTGry0D_TGe8QTrWj4LtaydUUWM")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.resource_type", response.get("transfers.data.transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_reference", response.get("transfers.data.transfer.transfer_reference"),"TRNREF_20160829130404970")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.payment_type", response.get("transfers.data.transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender_account_uri", response.get("transfers.data.transfer.sender_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.first_name", response.get("transfers.data.transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.middle_name", response.get("transfers.data.transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.last_name", response.get("transfers.data.transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.nationality", response.get("transfers.data.transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.date_of_birth", response.get("transfers.data.transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.line1", response.get("transfers.data.transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.line2", response.get("transfers.data.transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.city", response.get("transfers.data.transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.country_subdivision", response.get("transfers.data.transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.postal_code", response.get("transfers.data.transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.country", response.get("transfers.data.transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.phone", response.get("transfers.data.transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.email", response.get("transfers.data.transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient_account_uri", response.get("transfers.data.transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.first_name", response.get("transfers.data.transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.middle_name", response.get("transfers.data.transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.last_name", response.get("transfers.data.transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.nationality", response.get("transfers.data.transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.date_of_birth", response.get("transfers.data.transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.line1", response.get("transfers.data.transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.line2", response.get("transfers.data.transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.city", response.get("transfers.data.transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.country_subdivision", response.get("transfers.data.transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.postal_code", response.get("transfers.data.transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.country", response.get("transfers.data.transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.phone", response.get("transfers.data.transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.email", response.get("transfers.data.transfer.recipient.email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_amount.value", response.get("transfers.data.transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_amount.currency", response.get("transfers.data.transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.created", response.get("transfers.data.transfer.created"),"2016-08-29T08:07:37.282-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.resource_type", response.get("transfers.data.transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.item_count", response.get("transfers.data.transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.id", response.get("transfers.data.transfer.transaction_history.data.transaction.id"),"txn_SVDvtQk1mKcJefExHKpvVeLctXvJ")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.resource_type", response.get("transfers.data.transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.account_uri", response.get("transfers.data.transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfers.data.transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfers.data.transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network", response.get("transfers.data.transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network_status_code", response.get("transfers.data.transfer.transaction_history.data.transaction.network_status_code"),"00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network_status_description", response.get("transfers.data.transfer.transaction_history.data.transaction.network_status_description"),"Approved or completed successfully")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.funds_availability", response.get("transfers.data.transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.type", response.get("transfers.data.transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.create_timestamp", response.get("transfers.data.transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T08:07:37.288-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status", response.get("transfers.data.transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status_reason", response.get("transfers.data.transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status_timestamp", response.get("transfers.data.transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:07:37-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfers.data.transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[0].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[0].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[1].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[1].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[2].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[2].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.statement_descriptor", response.get("transfers.data.transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.channel", response.get("transfers.data.transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.status", response.get("transfers.data.transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.status_timestamp", response.get("transfers.data.transfer.status_timestamp"),"2016-08-29T08:07:37.374-05:00")
        

        BaseTest.putResponse("GetTransferByRef_NON_TOKENIZED", response)
        

    
        
    
        
        
        
        
        
        
                
    def test_32162_GetTransferByRef_TOKENIZED(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("ref", "TRNREF_20160829130737009")
        
        map.set("ref", BaseTest.resolveResponseValue("CreatePayment_TOKENIZED.transfer.transfer_reference"));
        
        response = PaymentTransfer.readByReference(map)

        ignoreAsserts = []
        ignoreAsserts.append("transfers.data.transfer.transfer_reference")
        ignoreAsserts.append("transfers.data.transfer.id")
        ignoreAsserts.append("transfers.data.transfer.created")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.id")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.create_timestamp")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.status_timestamp")
        ignoreAsserts.append("transfers.data.transfer.status_timestamp")
        ignoreAsserts.append("transfers.data.transfer.sender.email")
        ignoreAsserts.append("transfers.data.transfer.recipient.email")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.retrieval_reference")
        ignoreAsserts.append("transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number")
        ignoreAsserts.append("transfers.data.transfer.sender_account_uri")
        ignoreAsserts.append("transfers.data.transfer.statement_descriptor")
        
        self.customAssertEqual(ignoreAsserts, "transfers.resource_type", response.get("transfers.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfers.item_count", response.get("transfers.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.id", response.get("transfers.data.transfer.id"),"trn_4MMUC7147Vamd1IVt77DV0d-mIZr")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.resource_type", response.get("transfers.data.transfer.resource_type"),"transfer")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_reference", response.get("transfers.data.transfer.transfer_reference"),"TRNREF_20160829130737009")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.payment_type", response.get("transfers.data.transfer.payment_type"),"P2P")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender_account_uri", response.get("transfers.data.transfer.sender_account_uri"),"acct-ref:ref_20160407070850915")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.first_name", response.get("transfers.data.transfer.sender.first_name"),"John")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.middle_name", response.get("transfers.data.transfer.sender.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.last_name", response.get("transfers.data.transfer.sender.last_name"),"Jones")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.nationality", response.get("transfers.data.transfer.sender.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.date_of_birth", response.get("transfers.data.transfer.sender.date_of_birth"),"1994-05-21")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.line1", response.get("transfers.data.transfer.sender.address.line1"),"21 Broadway")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.line2", response.get("transfers.data.transfer.sender.address.line2"),"Apartment A-6")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.city", response.get("transfers.data.transfer.sender.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.country_subdivision", response.get("transfers.data.transfer.sender.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.postal_code", response.get("transfers.data.transfer.sender.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.address.country", response.get("transfers.data.transfer.sender.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.phone", response.get("transfers.data.transfer.sender.phone"),"11234565555")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.sender.email", response.get("transfers.data.transfer.sender.email"),"John.Jones123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient_account_uri", response.get("transfers.data.transfer.recipient_account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.first_name", response.get("transfers.data.transfer.recipient.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.middle_name", response.get("transfers.data.transfer.recipient.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.last_name", response.get("transfers.data.transfer.recipient.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.nationality", response.get("transfers.data.transfer.recipient.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.date_of_birth", response.get("transfers.data.transfer.recipient.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.line1", response.get("transfers.data.transfer.recipient.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.line2", response.get("transfers.data.transfer.recipient.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.city", response.get("transfers.data.transfer.recipient.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.country_subdivision", response.get("transfers.data.transfer.recipient.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.postal_code", response.get("transfers.data.transfer.recipient.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.address.country", response.get("transfers.data.transfer.recipient.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.phone", response.get("transfers.data.transfer.recipient.phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.recipient.email", response.get("transfers.data.transfer.recipient.email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_amount.value", response.get("transfers.data.transfer.transfer_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transfer_amount.currency", response.get("transfers.data.transfer.transfer_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.created", response.get("transfers.data.transfer.created"),"2016-08-29T08:11:02.799-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.resource_type", response.get("transfers.data.transfer.transaction_history.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.item_count", response.get("transfers.data.transfer.transaction_history.item_count"),"1")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.id", response.get("transfers.data.transfer.transaction_history.data.transaction.id"),"txn_S7hjCOKzzkSzeCTS7g-Fdq0_drCD")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.resource_type", response.get("transfers.data.transfer.transaction_history.data.transaction.resource_type"),"transaction")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.account_uri", response.get("transfers.data.transfer.transaction_history.data.transaction.account_uri"),"pan:************0018")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.transaction_amount.value", response.get("transfers.data.transfer.transaction_history.data.transaction.transaction_amount.value"),"1800")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.transaction_amount.currency", response.get("transfers.data.transfer.transaction_history.data.transaction.transaction_amount.currency"),"USD")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network", response.get("transfers.data.transfer.transaction_history.data.transaction.network"),"STAR")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network_status_code", response.get("transfers.data.transfer.transaction_history.data.transaction.network_status_code"),"00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.network_status_description", response.get("transfers.data.transfer.transaction_history.data.transaction.network_status_description"),"Approved or completed successfully")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.funds_availability", response.get("transfers.data.transfer.transaction_history.data.transaction.funds_availability"),"IMMEDIATE")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.type", response.get("transfers.data.transfer.transaction_history.data.transaction.type"),"PAYMENT")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.create_timestamp", response.get("transfers.data.transfer.transaction_history.data.transaction.create_timestamp"),"2016-08-29T08:11:02.805-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status", response.get("transfers.data.transfer.transaction_history.data.transaction.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status_reason", response.get("transfers.data.transfer.transaction_history.data.transaction.status_reason"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.status_timestamp", response.get("transfers.data.transfer.transaction_history.data.transaction.status_timestamp"),"2016-08-29T01:11:02-05:00")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.retrieval_reference", response.get("transfers.data.transfer.transaction_history.data.transaction.retrieval_reference"),"624200192616")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number", response.get("transfers.data.transfer.transaction_history.data.transaction.system_trace_audit_number"),"926162")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[0].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[0].name"),"ABC")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[0].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[0].value"),"123")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[1].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[1].name"),"DEF")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[1].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[1].value"),"456")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[2].name", response.get("transfers.data.transfer.reconciliation_data.custom_field[2].name"),"GHI")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.reconciliation_data.custom_field[2].value", response.get("transfers.data.transfer.reconciliation_data.custom_field[2].value"),"789")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.statement_descriptor", response.get("transfers.data.transfer.statement_descriptor"),"TST*THANKYOU")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.channel", response.get("transfers.data.transfer.channel"),"KIOSK")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.status", response.get("transfers.data.transfer.status"),"APPROVED")
        self.customAssertEqual(ignoreAsserts, "transfers.data.transfer.status_timestamp", response.get("transfers.data.transfer.status_timestamp"),"2016-08-29T08:11:02.895-05:00")
        

        BaseTest.putResponse("GetTransferByRef_TOKENIZED", response)
        

    
        
    
        
        
                
    def test_33003_SanctionScreening_NonTokenized(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("sanction_screening_input.screening_reference", "ABC_33003350923549292458")
        map.set("sanction_screening_input.consumer.first_name", "John")
        map.set("sanction_screening_input.consumer.middle_name", "M")
        map.set("sanction_screening_input.consumer.last_name", "Jones")
        map.set("sanction_screening_input.consumer.date_of_birth", "1990-01-01")
        map.set("sanction_screening_input.consumer.address.line1", "Mastercard Blvd")
        map.set("sanction_screening_input.consumer.address.line2", "Suite 240")
        map.set("sanction_screening_input.consumer.address.city", "ofallon")
        map.set("sanction_screening_input.consumer.address.state", "MO")
        map.set("sanction_screening_input.consumer.address.country", "USA")
        
        
        response = SanctionScreening(map).read()

        ignoreAsserts = []
        ignoreAsserts.append("sanction_screening.id")
        ignoreAsserts.append("sanction_screening.score")
        
        self.customAssertEqual(ignoreAsserts, "sanction_screening.id", response.get("sanction_screening.id"),"rqst_8A49-4DCB-8965-780B")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.resource_type", response.get("sanction_screening.resource_type"),"sanction_screening")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.screening_reference", response.get("sanction_screening.screening_reference"),"ABC_33003350923549292458")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.status", response.get("sanction_screening.status"),"SUCCESS")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.score", response.get("sanction_screening.score"),"50")
        

        BaseTest.putResponse("SanctionScreening_NonTokenized", response)
        

    
        
        
        
        
        
    
        
        
                
    def test_33004_SanctionScreeningBy_Tokenized_ConsumerId(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("sanction_screening_input.screening_reference", "ABC_33004350923549292458")
        map.set("sanction_screening_input.consumer_id", "cns_kiKj6mgInaCIE4OdVGLOY0eY3eu5")
        
        
        response = SanctionScreening(map).read()

        ignoreAsserts = []
        ignoreAsserts.append("sanction_screening.id")
        ignoreAsserts.append("sanction_screening.score")
        
        self.customAssertEqual(ignoreAsserts, "sanction_screening.id", response.get("sanction_screening.id"),"rqst_8A49-4DCB-8965-780B")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.resource_type", response.get("sanction_screening.resource_type"),"sanction_screening")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.screening_reference", response.get("sanction_screening.screening_reference"),"ABC_33004350923549292458")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.status", response.get("sanction_screening.status"),"SUCCESS")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.score", response.get("sanction_screening.score"),"50")
        

        BaseTest.putResponse("SanctionScreeningBy_Tokenized_ConsumerId", response)
        

    
        
        
        
        
        
    
        
        
                
    def test_33005_SanctionScreening_Tokenized_ConsumerReference(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("sanction_screening_input.screening_reference", "ABC_33005350923549292458")
        map.set("sanction_screening_input.consumer_reference", "AB123456")
        
        
        response = SanctionScreening(map).read()

        ignoreAsserts = []
        ignoreAsserts.append("sanction_screening.id")
        ignoreAsserts.append("sanction_screening.score")
        
        self.customAssertEqual(ignoreAsserts, "sanction_screening.id", response.get("sanction_screening.id"),"rqst_8A49-4DCB-8965-780B")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.resource_type", response.get("sanction_screening.resource_type"),"sanction_screening")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.screening_reference", response.get("sanction_screening.screening_reference"),"ABC_33005350923549292458")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.status", response.get("sanction_screening.status"),"SUCCESS")
        self.customAssertEqual(ignoreAsserts, "sanction_screening.score", response.get("sanction_screening.score"),"50")
        

        BaseTest.putResponse("SanctionScreening_Tokenized_ConsumerReference", response)
        

    
        
        
        
        
        
    
        
        
        
        
        
                
    def test_41001_RetrieveConsumerContactId(self):
        

        

        id = ""
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("contactId", "cntc_KHfVnuC9WAtO10aiL-DJWt6MTAz")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("contactId", BaseTest.resolveResponseValue("AddConsumerContactId.contact_id.id"));
        
        response = ConsumerContactID.read(id,map)

        ignoreAsserts = []
        ignoreAsserts.append("contact_id.id")
        ignoreAsserts.append("contact_id.contact_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "contact_id.id", response.get("contact_id.id"),"cntc_3747dskr4hrfjjd")
        self.customAssertEqual(ignoreAsserts, "contact_id.resource_type", response.get("contact_id.resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contact_id.contact_id_uri", response.get("contact_id.contact_id_uri"),"tel:12125559175")
        

        BaseTest.putResponse("RetrieveConsumerContactId", response)
        

    
        
        
    
        
        
        
        
        
        
                
    def test_42001_RetrieveConsumerContacts(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = ConsumerContactID.listAll(map)

        ignoreAsserts = []
        ignoreAsserts.append("contacts.item_count")
        ignoreAsserts.append("contacts.data.contact_id[0].id")
        ignoreAsserts.append("contacts.data.contact_id[0].contact_id_uri")
        ignoreAsserts.append("contacts.data.contact_id[1].id")
        ignoreAsserts.append("contacts.data.contact_id[1].contact_id_uri")
        ignoreAsserts.append("contacts.data.contact_id[2].id")
        ignoreAsserts.append("contacts.data.contact_id[2].contact_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "contacts.resource_type", response.get("contacts.resource_type"),"list")
        self.customAssertEqual(ignoreAsserts, "contacts.item_count", response.get("contacts.item_count"),"3")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[0].id", response.get("contacts.data.contact_id[0].id"),"cntc_HeVzmQRSWeaxiLcIH637BsprGLj")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[0].resource_type", response.get("contacts.data.contact_id[0].resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[0].contact_id_uri", response.get("contacts.data.contact_id[0].contact_id_uri"),"email:Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[1].id", response.get("contacts.data.contact_id[1].id"),"cntc_VkVIk_-tb6G1AuVmdcQuX_o61ga")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[1].resource_type", response.get("contacts.data.contact_id[1].resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[1].contact_id_uri", response.get("contacts.data.contact_id[1].contact_id_uri"),"tel:11234567890")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[2].id", response.get("contacts.data.contact_id[2].id"),"cntc_Dy-ajJKtCoq2N1l2IqK4jx4WPAR")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[2].resource_type", response.get("contacts.data.contact_id[2].resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contacts.data.contact_id[2].contact_id_uri", response.get("contacts.data.contact_id[2].contact_id_uri"),"tel:8491378015")
        

        BaseTest.putResponse("RetrieveConsumerContacts", response)
        

    
        
    
        
        
                
    def test_50033_UpdateConsumerAccount(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("accountId", "acct_mk32k324mg6wn19x")
        map.set("account.label", "JaneMC")
        map.set("account.account_uri", "pan:5432123456789012;exp=2017-02;cvc=123")
        map.set("account.name_on_account", "Jane Tyler Smith")
        map.set("account.address.line1", "1 Main St")
        map.set("account.address.line2", "Apartment 9")
        map.set("account.address.city", "OFallon")
        map.set("account.address.country_subdivision", "MO")
        map.set("account.address.postal_code", "63368")
        map.set("account.address.country", "USA")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("accountId", BaseTest.resolveResponseValue("AddConsumerAccount.account.id"));
        
        response = ConsumerAccount(map).update()

        ignoreAsserts = []
        ignoreAsserts.append("account.id")
        ignoreAsserts.append("account.account_uri")
        ignoreAsserts.append("account.account_reference")
        
        self.customAssertEqual(ignoreAsserts, "account.id", response.get("account.id"),"acct_Iqg1s2JGFhul9YRqAdQmY8lTiAG")
        self.customAssertEqual(ignoreAsserts, "account.resource_type", response.get("account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "account.account_reference", response.get("account.account_reference"),"ref_25738849186162645")
        self.customAssertEqual(ignoreAsserts, "account.label", response.get("account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "account.account_uri", response.get("account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "account.brand", response.get("account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account.name_on_account", response.get("account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "account.address.line1", response.get("account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "account.address.line2", response.get("account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "account.address.city", response.get("account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "account.address.country_subdivision", response.get("account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "account.address.postal_code", response.get("account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "account.address.country", response.get("account.address.country"),"USA")
        

        BaseTest.putResponse("UpdateConsumerAccount", response)
        

    
        
        
        
        
        
    
        
        
                
    def test_50043_UpdateConsumerContactId(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("contactId", "cntc_KHfVnuC9WAtO10aiL-DJWt6MTAz")
        map.set("contact_id.contact_id_uri", "tel:12125559175")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("contactId", BaseTest.resolveResponseValue("AddConsumerContactId.contact_id.id"));
        
        response = ConsumerContactID(map).update()

        ignoreAsserts = []
        ignoreAsserts.append("contact_id.id")
        ignoreAsserts.append("contact_id.contact_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "contact_id.id", response.get("contact_id.id"),"cntc_3747dskr4hrfjjd")
        self.customAssertEqual(ignoreAsserts, "contact_id.resource_type", response.get("contact_id.resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contact_id.contact_id_uri", response.get("contact_id.contact_id_uri"),"tel:12125559175")
        

        BaseTest.putResponse("UpdateConsumerContactId", response)
        

    
        
        
        
        
        
    
        
        
        
        
                
    def test_50134_DeleteConsumerAccount(self):
        

        

        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("accountId", "acct_mk32k324mg6wn19x")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("accountId", BaseTest.resolveResponseValue("AddConsumerAccount.account.id"));
        
        response = ConsumerAccount.deleteById("",map)
        self.assertNotEqual(response,None)

        ignoreAsserts = []
        ignoreAsserts.append("account.id")
        ignoreAsserts.append("account.account_uri")
        ignoreAsserts.append("account.account_reference")
        
        self.customAssertEqual(ignoreAsserts, "account.id", response.get("account.id"),"acct_mk32k324mg6wn19x")
        self.customAssertEqual(ignoreAsserts, "account.resource_type", response.get("account.resource_type"),"account")
        self.customAssertEqual(ignoreAsserts, "account.account_reference", response.get("account.account_reference"),"AB123456")
        self.customAssertEqual(ignoreAsserts, "account.label", response.get("account.label"),"JaneMC")
        self.customAssertEqual(ignoreAsserts, "account.account_uri", response.get("account.account_uri"),"pan:************9012")
        self.customAssertEqual(ignoreAsserts, "account.brand", response.get("account.brand"),"MasterCard")
        self.customAssertEqual(ignoreAsserts, "account.name_on_account", response.get("account.name_on_account"),"Jane Tyler Smith")
        self.customAssertEqual(ignoreAsserts, "account.address.line1", response.get("account.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "account.address.line2", response.get("account.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "account.address.city", response.get("account.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "account.address.country_subdivision", response.get("account.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "account.address.postal_code", response.get("account.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "account.address.country", response.get("account.address.country"),"USA")
        

        BaseTest.putResponse("DeleteConsumerAccount", response)
        

    

        
        
        
    
        
        
        
        
                
    def test_50144_DeleteConsumerContactId(self):
        

        

        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("contactId", "cntc_KHfVnuC9WAtO10aiL-DJWt6MTAz")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("contactId", BaseTest.resolveResponseValue("AddConsumerContactId.contact_id.id"));
        
        response = ConsumerContactID.deleteById("",map)
        self.assertNotEqual(response,None)

        ignoreAsserts = []
        ignoreAsserts.append("contact_id.id")
        ignoreAsserts.append("contact_id.contact_id_uri")
        
        self.customAssertEqual(ignoreAsserts, "contact_id.id", response.get("contact_id.id"),"cntc_3747dskr4hrfjjd")
        self.customAssertEqual(ignoreAsserts, "contact_id.resource_type", response.get("contact_id.resource_type"),"contact_id")
        self.customAssertEqual(ignoreAsserts, "contact_id.contact_id_uri", response.get("contact_id.contact_id_uri"),"tel:12125559175")
        

        BaseTest.putResponse("DeleteConsumerContactId", response)
        

    

        
        
        
    
        
        
                
    def test_60023_UpdateConsumer(self):
        

        
    
        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        map.set("consumer.first_name", "Jane")
        map.set("consumer.middle_name", "Tyler")
        map.set("consumer.last_name", "Smith")
        map.set("consumer.nationality", "USA")
        map.set("consumer.date_of_birth", "1999-12-30")
        map.set("consumer.address.line1", "1 Main St")
        map.set("consumer.address.line2", "Apartment 9")
        map.set("consumer.address.city", "OFallon")
        map.set("consumer.address.country_subdivision", "MO")
        map.set("consumer.address.postal_code", "63368")
        map.set("consumer.address.country", "USA")
        map.set("consumer.primary_phone", "11234567890")
        map.set("consumer.primary_email", "Jane.Smith123@abcmail.com")
        map.set("consumer.preferences.default_accounts.receiving", "acct_mk32k324mg6wn19x")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        map.set("consumer.preferences.default_accounts.receiving", BaseTest.resolveResponseValue("RegisterConsumer.consumer.preferences.default_accounts.receiving"));
        
        response = Consumer(map).update()

        ignoreAsserts = []
        ignoreAsserts.append("consumer.id")
        ignoreAsserts.append("consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumer.preferences.default_accounts.receiving")
        ignoreAsserts.append("consumer.consumer_reference")
        
        self.customAssertEqual(ignoreAsserts, "consumer.first_name", response.get("consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumer.middle_name", response.get("consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumer.last_name", response.get("consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumer.nationality", response.get("consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.date_of_birth", response.get("consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line1", response.get("consumer.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line2", response.get("consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumer.address.city", response.get("consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country_subdivision", response.get("consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumer.address.postal_code", response.get("consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country", response.get("consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_phone", response.get("consumer.primary_phone"),"11234567890")
        self.customAssertEqual(ignoreAsserts, "consumer.primary_email", response.get("consumer.primary_email"),"Jane.Smith123@abcmail.com")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.receiving", response.get("consumer.preferences.default_accounts.receiving"),"acct_H3tGYN9Mif22Wi7wGxBcaVxmwjY")
        

        BaseTest.putResponse("UpdateConsumer", response)
        

    
        
        
        
        
        
    
        
        
        
        
                
    def test_60024_DeleteConsumer(self):
        

        

        map = RequestMap()
        map.set("partnerId", "ptnr_BEeCrYJHh2BXTXPy_PEtp-8DBOo")
        map.set("consumerId", "cns_6psmQAn0Xg0_MovLrEEPg3Kv4QWi")
        
        map.set("consumerId", BaseTest.resolveResponseValue("RegisterConsumer.consumer.id"));
        
        response = Consumer.deleteById("",map)
        self.assertNotEqual(response,None)

        ignoreAsserts = []
        ignoreAsserts.append("consumer.id")
        ignoreAsserts.append("consumer.preferences.default_accounts.sending")
        ignoreAsserts.append("consumer.preferences.default_accounts.receiving")
        ignoreAsserts.append("consumer.consumer_reference")
        
        self.customAssertEqual(ignoreAsserts, "consumer.internalRequest", response.get("consumer.internalRequest"),"false")
        self.customAssertEqual(ignoreAsserts, "consumer.id", response.get("consumer.id"),"cns_0YcrEgG-sK0b6tWzG-1lM4ioMm9O")
        self.customAssertEqual(ignoreAsserts, "consumer.resource_type", response.get("consumer.resource_type"),"consumer")
        self.customAssertEqual(ignoreAsserts, "consumer.consumer_reference", response.get("consumer.consumer_reference"),"ref_257639634904596144")
        self.customAssertEqual(ignoreAsserts, "consumer.first_name", response.get("consumer.first_name"),"Jane")
        self.customAssertEqual(ignoreAsserts, "consumer.middle_name", response.get("consumer.middle_name"),"Tyler")
        self.customAssertEqual(ignoreAsserts, "consumer.last_name", response.get("consumer.last_name"),"Smith")
        self.customAssertEqual(ignoreAsserts, "consumer.nationality", response.get("consumer.nationality"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.date_of_birth", response.get("consumer.date_of_birth"),"1999-12-30")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line1", response.get("consumer.address.line1"),"1 Main St")
        self.customAssertEqual(ignoreAsserts, "consumer.address.line2", response.get("consumer.address.line2"),"Apartment 9")
        self.customAssertEqual(ignoreAsserts, "consumer.address.city", response.get("consumer.address.city"),"OFallon")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country_subdivision", response.get("consumer.address.country_subdivision"),"MO")
        self.customAssertEqual(ignoreAsserts, "consumer.address.postal_code", response.get("consumer.address.postal_code"),"63368")
        self.customAssertEqual(ignoreAsserts, "consumer.address.country", response.get("consumer.address.country"),"USA")
        self.customAssertEqual(ignoreAsserts, "consumer.preferences.default_accounts.receiving", response.get("consumer.preferences.default_accounts.receiving"),"acct_Ef-RjVN3N7c-Qmw6FKaFLPcJFGs")
        

        BaseTest.putResponse("DeleteConsumer", response)
        

    

        
        
        
    

if __name__ == '__main__':
    unittest.main()

